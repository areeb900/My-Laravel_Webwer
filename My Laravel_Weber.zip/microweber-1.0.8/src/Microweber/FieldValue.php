<?php


class FieldValue extends BaseModel
{
    public $table = 'custom_fields_values';
}
