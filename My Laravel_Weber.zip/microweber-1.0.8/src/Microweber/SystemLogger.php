<?php


class SystemLogger extends BaseModel
{
    public $table = 'log';
}
