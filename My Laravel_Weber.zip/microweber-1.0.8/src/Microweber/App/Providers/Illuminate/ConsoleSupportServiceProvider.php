<?php

namespace Microweber\App\Providers\Illuminate;

class ConsoleSupportServiceProvider extends \Illuminate\Foundation\Providers\ConsoleSupportServiceProvider{

}

