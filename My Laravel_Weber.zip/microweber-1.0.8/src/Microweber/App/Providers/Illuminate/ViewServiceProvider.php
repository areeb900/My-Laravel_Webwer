<?php

namespace Microweber\App\Providers\Illuminate;

class ViewServiceProvider extends \Illuminate\View\ViewServiceProvider
{

}


