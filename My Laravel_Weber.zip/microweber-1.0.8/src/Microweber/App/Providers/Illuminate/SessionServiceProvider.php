<?php

namespace Microweber\App\Providers\Illuminate;

class SessionServiceProvider extends \Illuminate\Session\SessionServiceProvider
{

}


