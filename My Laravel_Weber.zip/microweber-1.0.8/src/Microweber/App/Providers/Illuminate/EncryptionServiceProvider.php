<?php

namespace Microweber\App\Providers\Illuminate;

class EncryptionServiceProvider extends \Illuminate\Encryption\EncryptionServiceProvider
{

}


