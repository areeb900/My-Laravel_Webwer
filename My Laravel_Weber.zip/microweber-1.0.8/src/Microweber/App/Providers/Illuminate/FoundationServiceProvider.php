<?php

namespace Microweber\App\Providers\Illuminate;

class FoundationServiceProvider extends \Illuminate\Foundation\Providers\FoundationServiceProvider
{

}


