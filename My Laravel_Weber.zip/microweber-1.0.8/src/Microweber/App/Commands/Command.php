<?php namespace Microweber\App\Commands;

abstract class Command {

	//

}
