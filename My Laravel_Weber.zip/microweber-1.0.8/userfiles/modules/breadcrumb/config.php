<?php

$config = array();
$config['name'] = "Breadbrumb";
$config['description'] = "Breadbrumb navigation";
$config['author'] = "Microweber";
$config['ui'] = true;
$config['categories'] = "other";
$config['position'] = 54;
$config['version'] = 0.2;
