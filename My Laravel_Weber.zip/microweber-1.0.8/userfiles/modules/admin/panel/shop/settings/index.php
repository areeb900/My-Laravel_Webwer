<module type="shop/payments" view="admin" />
