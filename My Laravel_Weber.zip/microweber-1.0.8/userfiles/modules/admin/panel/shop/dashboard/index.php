<?php event_trigger('mw.admin.dashboard.content'); ?>
    <?php event_trigger('mw.admin.dashboard.main'); ?>
