<?php
$config = array();
$config['name'] = "Import";
$config['author'] = "Microweber";
 
$config['categories'] = "admin"; 
$config['version'] = 0.3;
$config['ui_admin'] = true;
$config['position'] = 99;
 
 