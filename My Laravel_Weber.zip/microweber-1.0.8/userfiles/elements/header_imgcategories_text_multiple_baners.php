<img class="element img-polaroid img-rounded" src="<?php print pixum(800,120); ?>" width="100%" />
<div class="mw-row">
  <div class="mw-col" style="width: 20%">
    <div class="mw-col-container">
      <div class="well"><module type="categories" for="content" /></div>
    </div>
  </div>
  <div class="mw-col" style="width: 50%">
    <div class="mw-col-container">
      <div class="well">
          <h2 class="element lipsum">Simple Text</h2>
          <p class="element lipsum"><?php print lipsum(); ?></p>
          <p class="element lipsum"><?php print lipsum(); ?></p>
      </div>
    </div>
  </div>
  <div class="mw-col" style="width: 30%">
    <div class="mw-col-container">
      <div class="element">
        <img class="element img-rounded img-polaroid" width="100%" src="<?php print pixum(300,200); ?>" />
          <div class="mw-row">
            <div class="mw-col" style="width: 50%">
              <div class="mw-col-container">
                <img class="element img-rounded img-polaroid" width="100%" src="<?php print pixum(150,150); ?>" />
                <img class="element img-rounded img-polaroid" width="100%" src="<?php print pixum(150,150); ?>" />
              </div>
            </div>
            <div class="mw-col" style="width: 50%">
              <div class="mw-col-container">
                <img class="element img-rounded img-polaroid" width="100%" src="<?php print pixum(150,150); ?>" />
                <img class="element img-rounded img-polaroid" width="100%" src="<?php print pixum(150,150); ?>" />
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
