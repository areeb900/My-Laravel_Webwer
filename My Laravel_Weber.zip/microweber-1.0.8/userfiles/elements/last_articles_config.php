<?php

$config = array();
$config['name'] = "Last articles";
$config['author'] = "Microweber";
$config['description'] = "Last articles";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "online shop, portfolio";
$config['version'] = 1.4;
$config['position'] = 18;
$config['as_element'] = true;
