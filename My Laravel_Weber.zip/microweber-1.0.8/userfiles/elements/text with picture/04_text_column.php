<img class="element img-polaroid" src="<?php print pixum(800, 150); ?>" width="100%" alt=""  />
<div class="well">
    <h2 class="element lipsum">Two Columns & Picture</h2>
    <p class="element lipsum"><?php print lipsum(); ?></p>
</div>
