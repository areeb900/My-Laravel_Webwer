<?php

$config = array();
$config['name'] = "Two Columns with Pictures";
$config['author'] = "Microweber";
$config['description'] = "2 columns with text and picture";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "online shop";
$config['position'] = "5";
$config['version'] = 0.1;
$config['as_element'] = true;