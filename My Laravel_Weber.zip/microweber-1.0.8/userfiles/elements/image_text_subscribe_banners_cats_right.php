<img class="element img-polaroid" width="100%" src="<?php print pixum(800,120); ?>" />
<div class="mw-row">
    <div class="mw-col" style="width: 40%">
      <div class="mw-col-container">
          <module type="newsletter" />
          <div class="mw-row">
              <div class="mw-col" style="width: 50%">
                <div class="mw-col-container">
                    <img class="element img-polaroid" style="margin: 0;" src="<?php print pixum(200,200); ?>" />
                    <img class="element img-polaroid" src="<?php print pixum(200,200); ?>" />
                </div>
              </div>
              <div class="mw-col" style="width: 50%">
                  <div class="mw-col-container">
                    <module type="categories" for="content" class="well nav nav-pills" />
                  </div>
              </div>
          </div>
      </div>
    </div>
    <div class="mw-col" style="width: 60%">
      <div class="mw-col-container">
          <h2 class="element lipsum">Simple text</h2>
          <div class="element">
              <p class="element lipsum"><?php print lipsum(); ?></p>
              <p class="element lipsum"><?php print lipsum(); ?></p>
              <p class="element lipsum"><?php print lipsum(); ?></p>
          </div>
      </div>
    </div>
</div>