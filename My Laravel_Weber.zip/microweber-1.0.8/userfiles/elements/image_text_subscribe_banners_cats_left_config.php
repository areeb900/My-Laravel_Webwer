<?php

$config = array();
$config['name'] = "Header Image text, newsletter, banners and categories.";
$config['author'] = "Microweber";
$config['description'] = "Header Image with text, newsletter, banners and categories.";
$config['website'] = "http://microweber.com";
$config['no_cache'] = true;
$config['categories'] = "custom";
$config['version'] = 0.2;
$config['position'] = 15;
$config['as_element'] = true;
